# UTM TV — Coming Soon

Single-page vaporwave landing page. Three.js carousel of six photos orbiting a
neon-framed logo, with a retro sun, perspective grid, and CRT post-processing.

## Run

```bash
npm install
npm run dev      # http://localhost:5173
```

## Deploy

Any static host serving `dist/` works (Vercel, Netlify, Cloudflare Pages,
Nginx, S3+CloudFront). Asset URLs are relative (`base: './'`), so sub-paths
work too.

```bash
npm run build    # typecheck + bundle to dist/
npm run preview  # serve the production build at http://localhost:4173
```

- `dist/` is self-contained: `index.html` + hashed JS/CSS + `assets/` photos.
- `public/_headers` sets cache policy on Cloudflare Pages / Netlify:
  hashed JS/CSS immutable 1y, photos revalidated weekly, HTML no-cache.
- `vercel.json` / `netlify.toml` carry the same policy to those platforms.
- `Dockerfile` + `nginx.conf`: `docker build -t comingsoon .` then run on port 80.
- Photos are pre-optimized WebP (1200px max height, ~350 KB total).

## Layout

```
index.html            page shell: canvas, DOM overlay, loader
public/assets/        logo.png + 6 photos (served as-is, not hashed)
src/
  config.ts           colors, ring layout, copy, photo order
  main.ts             bootstrap, render loop, visibility handling
  style.css           vaporwave theme, CRT overlay, intro states
  core/loader.ts      byte-accurate progress, texture creation
  scene/world.ts      renderer, camera, sun, grid, stars, horizon glow
  scene/carousel.ts   photo ring + logo, per-panel facing response
  scene/pointer.ts    pointer parallax, drag-to-spin, keyboard
  scene/post.ts       bloom + CRT/vignette/grain pass
  ui/headline.ts      scramble-text reveal
```

## Tuning

Most visual values live in `src/config.ts`:

| Key | Effect |
| --- | --- |
| `RING.radius` / `RING.planeHeight` | carousel size |
| `RING.speed` | auto-rotation speed |
| `RING.backFade` | how much rear panels dim |
| `LOGO.glowIntensity` | halo behind the logo |
| `BLOOM.strength` / `threshold` | neon glow |
| `GRID.opacity` / `SUN.radius` | environment |
| `PHOTOS` | file order, edge color, per-card tilt |

## Notes

- Photos are served as optimized WebP (~350 KB total). The loader shows real
  byte progress; the logo resolves first and the scene renders while photos
  stream in.
- Photo cards apply a brightness lift and a light neon duotone tint, because the
  source images are very dark (average RGB is around 20/25/35).
- Respects `prefers-reduced-motion`: auto-rotation slows, grain and scanlines
  are reduced, and the headline appears without the scramble effect.
- The render loop stops on `visibilitychange` and resumes on return.
